define( function() {
	"use strict";

	// All support tests are defined in their respective modules.
	return {};
} );
