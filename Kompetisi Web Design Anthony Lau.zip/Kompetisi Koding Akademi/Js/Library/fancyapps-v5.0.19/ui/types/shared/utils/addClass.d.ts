export declare const addClass: (el: HTMLElement | null, classes?: string) => void;
