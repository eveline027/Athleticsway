export declare const toggleClass: (el: HTMLElement, classes?: string, condition?: boolean) => void;
