/**
 * Detect if rendering from the client or the server
 */
export declare const canUseDOM: boolean;
