export declare const removeClass: (el: HTMLElement | null, classes?: string) => void;
