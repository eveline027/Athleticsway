import { PluginsType } from "../types";
export declare const Plugins: PluginsType;
