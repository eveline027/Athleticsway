export declare const en: {
    PANUP: string;
    PANDOWN: string;
    PANLEFT: string;
    PANRIGHT: string;
    ZOOMIN: string;
    ZOOMOUT: string;
    TOGGLEZOOM: string;
    TOGGLE1TO1: string;
    ITERATEZOOM: string;
    ROTATECCW: string;
    ROTATECW: string;
    FLIPX: string;
    FLIPY: string;
    FITX: string;
    FITY: string;
    RESET: string;
    TOGGLEFS: string;
};
