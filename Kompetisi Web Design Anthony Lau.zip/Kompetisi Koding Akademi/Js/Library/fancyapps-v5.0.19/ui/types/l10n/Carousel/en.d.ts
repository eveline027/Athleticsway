export declare const en: {
    NEXT: string;
    PREV: string;
    GOTO: string;
};
